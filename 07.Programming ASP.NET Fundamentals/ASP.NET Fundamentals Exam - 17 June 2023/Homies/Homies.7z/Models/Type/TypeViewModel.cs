﻿namespace Homies.Models.Type;

public class TypeViewModel
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;
}

