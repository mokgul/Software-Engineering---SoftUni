﻿
namespace MilitaryElite.Enums
{
    public enum State
    {
        inProgress = 0,
        Finished = 1
    }
}
