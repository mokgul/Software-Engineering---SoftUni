﻿
namespace BirthdayCelebrations.IO.Interfaces
{
    public interface IWriter
    {
        void Write(string value);

        void WriteLine(string value);
    }
}
