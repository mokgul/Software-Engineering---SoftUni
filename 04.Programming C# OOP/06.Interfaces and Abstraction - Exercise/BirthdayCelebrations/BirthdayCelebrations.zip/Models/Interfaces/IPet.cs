﻿
namespace BirthdayCelebrations.Models.Interfaces
{
    public interface IPet : IBirthdate
    {
        string Name { get; }
    }
}
