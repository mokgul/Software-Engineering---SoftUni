﻿
namespace BirthdayCelebrations.Models.Interfaces
{
    public interface IBirthdate
    {
        string Birthdate { get; }
    }
}
