﻿
namespace ExplicitInterfaces.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
