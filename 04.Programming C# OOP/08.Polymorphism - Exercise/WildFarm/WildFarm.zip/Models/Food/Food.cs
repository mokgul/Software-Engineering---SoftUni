﻿namespace WildFarm.Models.Food
{
    using Interfaces;
    public abstract class Food : IFood
    {
        protected Food(int quantity)
        {
            Quantity = quantity;
        }
        public int Quantity { get; private set; }
    }
}
