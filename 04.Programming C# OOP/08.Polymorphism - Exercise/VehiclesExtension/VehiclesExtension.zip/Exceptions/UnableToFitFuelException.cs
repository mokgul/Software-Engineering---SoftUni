﻿
namespace VehiclesExtension.Exceptions
{
    using System;
    public class UnableToFitFuelException : Exception
    {
        public UnableToFitFuelException(string message) : base(message)
        {

        }
    }
}
