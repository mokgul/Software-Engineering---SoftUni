﻿
namespace VehiclesExtension.Exceptions
{
    using System;
    public class InvalidFuelValue : Exception
    {
        public InvalidFuelValue(string message) : base(message)
        {

        }
    }
}
