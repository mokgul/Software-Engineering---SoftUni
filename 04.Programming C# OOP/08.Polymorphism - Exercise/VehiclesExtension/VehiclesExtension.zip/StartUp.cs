﻿using VehiclesExtension.Core;
using VehiclesExtension.Core.Interfaces;
using VehiclesExtension.IO;
using VehiclesExtension.IO.Interfaces;

namespace Vehicles
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();

            IEngine engine = new Engine(reader, writer);
            engine.Run();
        }
    }
}

// have a few errors to fix, refuel doesnt work properly, drive doesnt work properly,
//wrong calculations is my guess
