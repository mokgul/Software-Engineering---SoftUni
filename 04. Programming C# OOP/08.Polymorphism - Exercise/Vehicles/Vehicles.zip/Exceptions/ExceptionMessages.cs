﻿
namespace Vehicles.Exceptions
{
    public class ExceptionMessages
    {
        public const string InsufficientFuelExceptionMessage =
            "{0} needs refueling";
    }
}
