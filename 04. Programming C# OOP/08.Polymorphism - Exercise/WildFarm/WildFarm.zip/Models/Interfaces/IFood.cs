﻿
namespace WildFarm.Models.Interfaces
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
