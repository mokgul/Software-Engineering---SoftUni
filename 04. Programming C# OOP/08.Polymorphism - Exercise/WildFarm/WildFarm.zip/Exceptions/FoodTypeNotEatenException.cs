﻿
namespace WildFarm.Exceptions
{
    using System;
    public class FoodTypeNotEatenException 
    {
        public const string DEFAULT_MESSAGE = "{0} does not eat {1}!";

        public FoodTypeNotEatenException()
        {
            
        }
    }
}
