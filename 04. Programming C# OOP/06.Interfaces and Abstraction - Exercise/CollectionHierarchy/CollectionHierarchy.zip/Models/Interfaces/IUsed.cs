﻿namespace CollectionHierarchy.Models.Interfaces
{
    public interface IUsed : IRemove
    {
        int Count();
    }
}