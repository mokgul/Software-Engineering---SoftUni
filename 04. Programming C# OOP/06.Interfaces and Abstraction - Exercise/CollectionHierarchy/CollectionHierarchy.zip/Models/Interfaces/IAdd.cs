﻿
namespace CollectionHierarchy.Models.Interfaces
{
    public interface IAdd
    {
        int Add(string value);
    }
}
