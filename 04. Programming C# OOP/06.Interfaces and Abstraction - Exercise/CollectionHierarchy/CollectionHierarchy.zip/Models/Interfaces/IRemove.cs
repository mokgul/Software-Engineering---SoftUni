﻿
namespace CollectionHierarchy.Models.Interfaces
{
    public interface IRemove : IAdd
    {
        string Remove();
    }
}
