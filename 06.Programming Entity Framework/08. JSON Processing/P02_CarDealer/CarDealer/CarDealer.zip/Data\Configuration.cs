﻿namespace CarDealer.Data;

public static class Configuration
{
    public const string ConnectionString = @"Server=(LocalDB)\db charp softuni;Database=CarDealer;Integrated Security=True;Encrypt=False";
}

