﻿namespace ProductShop.Data;

public static class Configuration
{
    public const string ConnectionString = @"Server=(LocalDB)\db charp softuni;Database=ProductShop_XML;Integrated Security=True;Encrypt=False";
}

