﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=(LocalDB)\\db charp softuni;Database=BookShop;Integrated Security=True;";
    }
}
