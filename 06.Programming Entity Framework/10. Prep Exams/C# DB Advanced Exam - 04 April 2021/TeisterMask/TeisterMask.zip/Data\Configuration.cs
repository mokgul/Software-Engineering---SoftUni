﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=(LocalDB)\db charp softuni;Database=TeisterMaskExam;Integrated Security=True;Encrypt=False";
    }
}
