﻿
namespace Artillery.DataProcessor
{
    using Artillery.Data;

    public class Serializer
    {
        public static string ExportShells(ArtilleryContext context, double shellWeight)
        {
            return "";
        }

        public static string ExportGuns(ArtilleryContext context, string manufacturer)
        {
            return "";
        }
    }
}
