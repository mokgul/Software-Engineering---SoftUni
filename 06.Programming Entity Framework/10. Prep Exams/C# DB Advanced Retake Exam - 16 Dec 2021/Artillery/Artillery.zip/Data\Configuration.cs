﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=(LocalDB)\db charp softuni;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
