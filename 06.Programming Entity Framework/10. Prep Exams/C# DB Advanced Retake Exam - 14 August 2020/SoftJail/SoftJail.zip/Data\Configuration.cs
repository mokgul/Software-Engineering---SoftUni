﻿namespace SoftJail.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=(LocalDB)\db charp softuni;Database=SoftJail;Integrated Security=True;Encrypt=False;";
    }
}
