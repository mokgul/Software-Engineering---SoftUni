﻿namespace Trucks.Data;

public static class Configuration
{
    public static string ConnectionString = @"Server=(LocalDB)\db charp softuni;Database=Trucks;Trusted_Connection=True;Integrated Security=True";
}
