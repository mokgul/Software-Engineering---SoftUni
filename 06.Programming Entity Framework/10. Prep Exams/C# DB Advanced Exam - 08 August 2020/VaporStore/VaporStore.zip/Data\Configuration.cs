﻿namespace VaporStore.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=(LocalDB)\db charp softuni;Database=VaporStore;Trusted_Connection=True;Integrated Security=True";
    }
}