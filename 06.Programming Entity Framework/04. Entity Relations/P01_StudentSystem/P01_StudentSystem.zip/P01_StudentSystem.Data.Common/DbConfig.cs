﻿namespace P01_StudentSystem.Data.Common;

public class DbConfig
{
    public const string ConnectionString =
            @"Server=(LocalDB)\db charp softuni; Database=StudentSystem; Integrated Security=true";
}
