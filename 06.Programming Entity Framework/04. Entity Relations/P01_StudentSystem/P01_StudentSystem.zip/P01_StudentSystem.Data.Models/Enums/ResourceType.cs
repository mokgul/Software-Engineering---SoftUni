﻿namespace P01_StudentSystem.Data.Models.Enums;

public enum ResourceType
{
    Video = 0,
    Presentation = 1,
    Document = 2,
    Other = 3,
}