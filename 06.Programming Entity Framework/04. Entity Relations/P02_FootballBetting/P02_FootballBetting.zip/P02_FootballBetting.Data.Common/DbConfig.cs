﻿namespace P02_FootballBetting.Data.Common;

public class DbConfig
{
    public const string ConnectionString =
        @"Server=(LocalDB)\db charp softuni; Database=FootballBetting; Integrated Security=true";
}
