﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=(LocalDB)\db charp softuni; Database=MusicHub; Integrated Security=true";
    }
}
