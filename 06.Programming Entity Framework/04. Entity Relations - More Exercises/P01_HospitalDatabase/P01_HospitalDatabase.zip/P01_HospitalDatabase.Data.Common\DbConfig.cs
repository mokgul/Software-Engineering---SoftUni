﻿namespace P01_HospitalDatabase.Data.Common
{
    public class DbConfig
    {
        public const string ConnectionString =
            @"Server=(LocalDB)\db charp softuni; Database=HospitalDatabase; Integrated Security=true";
    }
}