﻿namespace P03_SalesDatabase.Data.Common;

public class DbConfig
{
    public const string ConnectionString =
        @"Server=(LocalDB)\db charp softuni; Database=SalesDatabase; Integrated Security=true";
}
